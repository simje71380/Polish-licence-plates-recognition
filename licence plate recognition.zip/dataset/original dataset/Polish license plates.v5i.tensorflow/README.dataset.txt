# Polish license plates > 2023-10-05 9:37pm
https://universe.roboflow.com/licenseplate-d9m5u/polish-license-plates

Provided by a Roboflow user
License: Public Domain

